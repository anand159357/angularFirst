import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  cmpys:string[]=["CTS","Microsoft","Wipro","TCS"];
  formApp:FormGroup;
  constructor(private form:FormBuilder) { 
    this.createForm();
  }

  ngOnInit() {
    this.formApp.setValue({
      fName:'Anand kumar',
      lName:'Seelam',
      pno:9962082366,
      comp:'CTS',
      gender:'Male',
      address:'On planet'
    })
  }
  createForm(){
    this.formApp=this.form.group({
      fName:['',Validators.required],
      lName:['',Validators.required],
      pno:['',Validators.compose([Validators.minLength(10),Validators.maxLength(10)])],
      comp:['Select Company'],
      gender:[''],
      address:''
    })
  }
  subApp(){

  }
}
