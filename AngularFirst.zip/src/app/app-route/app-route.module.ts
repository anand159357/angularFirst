import { AppComponent } from './../app.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FirstComponent } from '../Components/first/first.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const routes:Routes=[
  {path:'',component:FirstComponent}
];
@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes),NgbModule
  ],
  declarations: []
})
export class AppRouteModule { }
