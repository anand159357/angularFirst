import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {RouterModule} from '@angular/router'
import { AppComponent } from './app.component';
import { HeaderComponent } from './Components/header/header.component';
import { FooterComponent } from './Components/footer/footer.component';
import { FirstComponent } from './Components/first/first.component';
import { PageNotfoundComponent } from './Shared/page-notfound/page-notfound.component';
import { AppRouteModule } from './app-route/app-route.module';
import {ReactiveFormsModule} from '@angular/forms'


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FirstComponent,
    PageNotfoundComponent
  ],
  imports: [
    BrowserModule,RouterModule,AppRouteModule,NgbModule.forRoot(),ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
